

#region using statements

using DataJuggler.Excelerate;
using DataJuggler.Net7;
using DataJuggler.UltimateHelper;
using System;
using System.Collections.Generic;

#endregion

namespace Demo
{

    #region class Data
    public class Data
    {

        #region Private Variables
        private DateTime date;
        private Guid rowId;
        private int twitter;
        private int youTube;
        #endregion

        #region Methods

            #region Load(Row row)
            /// <summary>
            /// This method loads a Data object from a Row.
            /// </Summary>
            /// <param name="row">The row which the row.Columns[x].ColumnValue will be used to load this object.</param>
            public void Load(Row row)
            {
                // If the row exists and the row's column collection exists
                if ((NullHelper.Exists(row)) && (row.HasColumns))
                {
                    Date = row.Columns[0].DateValue;
                    Twitter = row.Columns[1].IntValue;
                    YouTube = row.Columns[2].IntValue;
                }

                // Set RowId
                RowId = row.Id;
            }
            #endregion

            #region Load(Worksheet worksheet)
            /// <summary>
            /// This method loads a list of Data objects from a Worksheet.
            /// </Summary>
            /// <param name="worksheet">The worksheet which the rows collection will be used to load a list of Data objects.</param>
            public static List<Data> Load(Worksheet worksheet)
            {
                // Initial value
                List<Data> dataList = new List<Data>();
                
                // If the worksheet exists and the row's collection exists
                if ((NullHelper.Exists(worksheet)) && (worksheet.HasRows))
                {
                    // Iterate the worksheet.Rows collection
                    foreach (Row row in worksheet.Rows)
                    {
                        // If the row is not a HeaderRow and row's column collection exists
                        if ((!row.IsHeaderRow) && (row.HasColumns))
                        {
                            // Create a new instance of a Data object.
                            Data data = new Data();
                            
                            // Load this object
                            data.Load(row);
                            
                            // Add this object to the list
                            dataList.Add(data);
                        }
                    }
                }
                
                // return value
                return dataList;
            }
            #endregion

            #region NewRow(Row row)
            /// <summary>
            /// This method creates the columns for the row to save a new Data object.
            /// </Summary>
            /// <param name="row">The row which the Columns will be created for.</param>
            public static Row NewRow(int rowNumber)
            {
                // initial value
                Row newRow = new Row();

                // Create Column
                Column dateColumn = new Column("Date", rowNumber, 1, DataManager.DataTypeEnum.DateTime);

                // Add this column
                newRow.Columns.Add(dateColumn);

                // Create Column
                Column twitterColumn = new Column("Twitter", rowNumber, 2, DataManager.DataTypeEnum.Integer);

                // Add this column
                newRow.Columns.Add(twitterColumn);

                // Create Column
                Column youTubeColumn = new Column("YouTube", rowNumber, 3, DataManager.DataTypeEnum.Integer);

                // Add this column
                newRow.Columns.Add(youTubeColumn);

                // return value
                return newRow;
            }
            #endregion

            #region Save(Row row)
            /// <summary>
            /// This method saves a Data object back to a Row.
            /// </Summary>
            /// <param name="row">The row which the row.Columns[x].ColumnValue will be set to Save back to Excel.</param>
            public Row Save(Row row)
            {
                // If the row exists and the row's column collection exists
                if ((NullHelper.Exists(row)) && (row.HasColumns))
                {
                    row.Columns[0].ColumnValue = Date;
                    row.Columns[1].ColumnValue = Twitter;
                    row.Columns[2].ColumnValue = YouTube;
                }

                // return value
                return row;
            }
            #endregion

        #endregion

        #region Properties

            #region DateTime Date
            public DateTime Date
            {
                get
                {
                    return date;
                }
                set
                {
                    date = value;
                }
            }
            #endregion

            #region Guid RowId
            public Guid RowId
            {
                get
                {
                    return rowId;
                }
                set
                {
                    rowId = value;
                }
            }
            #endregion

            #region int Twitter
            public int Twitter
            {
                get
                {
                    return twitter;
                }
                set
                {
                    twitter = value;
                }
            }
            #endregion

            #region int YouTube
            public int YouTube
            {
                get
                {
                    return youTube;
                }
                set
                {
                    youTube = value;
                }
            }
            #endregion

        #endregion

    }
    #endregion

}