

#region using statements

using DataJuggler.Excelerate;
using DataJuggler.Net6;
using DataJuggler.UltimateHelper;
using System;
using System.Collections.Generic;

#endregion

namespace Demo
{

    #region class BonusSettings
    public class BonusSettings
    {

        #region Private Variables
        private string branch;
        private int branchBonus;
        private string branchBonusEarned;
        private string branchExceededGoal;
        private int branchGoal;
        private int branchIncrement;
        private int branchIncrementBonus;
        private double branchYearToDate;
        private int companyBonus;
        private string companyBonusEarned;
        private int companyGoal;
        private double companyYearToDate;
        private string name;
        private Guid rowId;
        private int year;
        #endregion

        #region Methods

            #region Load(Row row)
            /// <summary>
            /// This method loads a BonusSettings object from a Row.
            /// </Summary>
            /// <param name="row">The row which the row.Columns[x].ColumnValue will be used to load this object.</param>
            public void Load(Row row)
            {
                // If the row exists and the row's column collection exists
                if ((NullHelper.Exists(row)) && (row.HasColumns))
                {
                    Branch = row.Columns[0].StringValue;
                    Name = row.Columns[1].StringValue;
                    Year = row.Columns[2].IntValue;
                    CompanyGoal = row.Columns[3].IntValue;
                    CompanyYearToDate = row.Columns[4].ColumnValue;
                    CompanyBonus = row.Columns[5].IntValue;
                    BranchGoal = row.Columns[6].IntValue;
                    BranchIncrement = row.Columns[7].IntValue;
                    BranchYearToDate = row.Columns[8].ColumnValue;
                    BranchBonus = row.Columns[9].IntValue;
                    BranchIncrementBonus = row.Columns[10].IntValue;
                    BranchExceededGoal = row.Columns[11].StringValue;
                    CompanyBonusEarned = row.Columns[12].StringValue;
                    BranchBonusEarned = row.Columns[13].StringValue;
                }

                // Set RowId
                RowId = row.Id;
            }
            #endregion

            #region Load(Worksheet worksheet)
            /// <summary>
            /// This method loads a list of BonusSettings objects from a Worksheet.
            /// </Summary>
            /// <param name="worksheet">The worksheet which the rows collection will be used to load a list of BonusSettings objects.</param>
            public static List<BonusSettings> Load(Worksheet worksheet)
            {
                // Initial value
                List<BonusSettings> bonusSettingsList = new List<BonusSettings>();
                
                // If the worksheet exists and the row's collection exists
                if ((NullHelper.Exists(worksheet)) && (worksheet.HasRows))
                {
                    // Iterate the worksheet.Rows collection
                    foreach (Row row in worksheet.Rows)
                    {
                        // If the row is not a HeaderRow and row's column collection exists
                        if ((!row.IsHeaderRow) && (row.HasColumns))
                        {
                            // Create a new instance of a BonusSettings object.
                            BonusSettings bonusSettings = new BonusSettings();
                            
                            // Load this object
                            bonusSettings.Load(row);
                            
                            // Add this object to the list
                            bonusSettingsList.Add(bonusSettings);
                        }
                    }
                }
                
                // return value
                return bonusSettingsList;
            }
            #endregion

            #region NewRow(Row row)
            /// <summary>
            /// This method creates the columns for the row to save a new BonusSettings object.
            /// </Summary>
            /// <param name="row">The row which the Columns will be created for.</param>
            public static Row NewRow(int rowNumber)
            {
                // initial value
                Row newRow = new Row();

                // Create Column
                Column branchColumn = new Column("Branch", rowNumber, 1, DataManager.DataTypeEnum.String);

                // Add this column
                newRow.Columns.Add(branchColumn);

                // Create Column
                Column nameColumn = new Column("Name", rowNumber, 2, DataManager.DataTypeEnum.String);

                // Add this column
                newRow.Columns.Add(nameColumn);

                // Create Column
                Column yearColumn = new Column("Year", rowNumber, 3, DataManager.DataTypeEnum.Integer);

                // Add this column
                newRow.Columns.Add(yearColumn);

                // Create Column
                Column companyGoalColumn = new Column("CompanyGoal", rowNumber, 4, DataManager.DataTypeEnum.Integer);

                // Add this column
                newRow.Columns.Add(companyGoalColumn);

                // Create Column
                Column companyYearToDateColumn = new Column("CompanyYearToDate", rowNumber, 5, DataManager.DataTypeEnum.Double);

                // Add this column
                newRow.Columns.Add(companyYearToDateColumn);

                // Create Column
                Column companyBonusColumn = new Column("CompanyBonus", rowNumber, 6, DataManager.DataTypeEnum.Integer);

                // Add this column
                newRow.Columns.Add(companyBonusColumn);

                // Create Column
                Column branchGoalColumn = new Column("BranchGoal", rowNumber, 7, DataManager.DataTypeEnum.Integer);

                // Add this column
                newRow.Columns.Add(branchGoalColumn);

                // Create Column
                Column branchIncrementColumn = new Column("BranchIncrement", rowNumber, 8, DataManager.DataTypeEnum.Integer);

                // Add this column
                newRow.Columns.Add(branchIncrementColumn);

                // Create Column
                Column branchYearToDateColumn = new Column("BranchYearToDate", rowNumber, 9, DataManager.DataTypeEnum.Double);

                // Add this column
                newRow.Columns.Add(branchYearToDateColumn);

                // Create Column
                Column branchBonusColumn = new Column("BranchBonus", rowNumber, 10, DataManager.DataTypeEnum.Integer);

                // Add this column
                newRow.Columns.Add(branchBonusColumn);

                // Create Column
                Column branchIncrementBonusColumn = new Column("BranchIncrementBonus", rowNumber, 11, DataManager.DataTypeEnum.Integer);

                // Add this column
                newRow.Columns.Add(branchIncrementBonusColumn);

                // Create Column
                Column branchExceededGoalColumn = new Column("BranchExceededGoal", rowNumber, 12, DataManager.DataTypeEnum.String);

                // Add this column
                newRow.Columns.Add(branchExceededGoalColumn);

                // Create Column
                Column companyBonusEarnedColumn = new Column("CompanyBonusEarned", rowNumber, 13, DataManager.DataTypeEnum.String);

                // Add this column
                newRow.Columns.Add(companyBonusEarnedColumn);

                // Create Column
                Column branchBonusEarnedColumn = new Column("BranchBonusEarned", rowNumber, 14, DataManager.DataTypeEnum.String);

                // Add this column
                newRow.Columns.Add(branchBonusEarnedColumn);

                // return value
                return newRow;
            }
            #endregion

            #region Save(Row row)
            /// <summary>
            /// This method saves a BonusSettings object back to a Row.
            /// </Summary>
            /// <param name="row">The row which the row.Columns[x].ColumnValue will be set to Save back to Excel.</param>
            public Row Save(Row row)
            {
                // If the row exists and the row's column collection exists
                if ((NullHelper.Exists(row)) && (row.HasColumns))
                {
                    row.Columns[0].ColumnValue = Branch;
                    row.Columns[1].ColumnValue = Name;
                    row.Columns[2].ColumnValue = Year;
                    row.Columns[3].ColumnValue = CompanyGoal;
                    row.Columns[4].ColumnValue = CompanyYearToDate;
                    row.Columns[5].ColumnValue = CompanyBonus;
                    row.Columns[6].ColumnValue = BranchGoal;
                    row.Columns[7].ColumnValue = BranchIncrement;
                    row.Columns[8].ColumnValue = BranchYearToDate;
                    row.Columns[9].ColumnValue = BranchBonus;
                    row.Columns[10].ColumnValue = BranchIncrementBonus;
                    row.Columns[11].ColumnValue = BranchExceededGoal;
                    row.Columns[12].ColumnValue = CompanyBonusEarned;
                    row.Columns[13].ColumnValue = BranchBonusEarned;
                }

                // return value
                return row;
            }
            #endregion

        #endregion

        #region Properties

            #region string Branch
            public string Branch
            {
                get
                {
                    return branch;
                }
                set
                {
                    branch = value;
                }
            }
            #endregion

            #region int BranchBonus
            public int BranchBonus
            {
                get
                {
                    return branchBonus;
                }
                set
                {
                    branchBonus = value;
                }
            }
            #endregion

            #region string BranchBonusEarned
            public string BranchBonusEarned
            {
                get
                {
                    return branchBonusEarned;
                }
                set
                {
                    branchBonusEarned = value;
                }
            }
            #endregion

            #region string BranchExceededGoal
            public string BranchExceededGoal
            {
                get
                {
                    return branchExceededGoal;
                }
                set
                {
                    branchExceededGoal = value;
                }
            }
            #endregion

            #region int BranchGoal
            public int BranchGoal
            {
                get
                {
                    return branchGoal;
                }
                set
                {
                    branchGoal = value;
                }
            }
            #endregion

            #region int BranchIncrement
            public int BranchIncrement
            {
                get
                {
                    return branchIncrement;
                }
                set
                {
                    branchIncrement = value;
                }
            }
            #endregion

            #region int BranchIncrementBonus
            public int BranchIncrementBonus
            {
                get
                {
                    return branchIncrementBonus;
                }
                set
                {
                    branchIncrementBonus = value;
                }
            }
            #endregion

            #region double BranchYearToDate
            public double BranchYearToDate
            {
                get
                {
                    return branchYearToDate;
                }
                set
                {
                    branchYearToDate = value;
                }
            }
            #endregion

            #region int CompanyBonus
            public int CompanyBonus
            {
                get
                {
                    return companyBonus;
                }
                set
                {
                    companyBonus = value;
                }
            }
            #endregion

            #region string CompanyBonusEarned
            public string CompanyBonusEarned
            {
                get
                {
                    return companyBonusEarned;
                }
                set
                {
                    companyBonusEarned = value;
                }
            }
            #endregion

            #region int CompanyGoal
            public int CompanyGoal
            {
                get
                {
                    return companyGoal;
                }
                set
                {
                    companyGoal = value;
                }
            }
            #endregion

            #region double CompanyYearToDate
            public double CompanyYearToDate
            {
                get
                {
                    return companyYearToDate;
                }
                set
                {
                    companyYearToDate = value;
                }
            }
            #endregion

            #region string Name
            public string Name
            {
                get
                {
                    return name;
                }
                set
                {
                    name = value;
                }
            }
            #endregion

            #region Guid RowId
            public Guid RowId
            {
                get
                {
                    return rowId;
                }
                set
                {
                    rowId = value;
                }
            }
            #endregion

            #region int Year
            public int Year
            {
                get
                {
                    return year;
                }
                set
                {
                    year = value;
                }
            }
            #endregion

        #endregion

    }
    #endregion

}