

#region using statements

using DataJuggler.Excelerate;
using DataJuggler.Net6;
using DataJuggler.UltimateHelper;
using System;
using System.Collections.Generic;

#endregion

namespace Test
{

    #region class BonusSettings
    public class BonusSettings
    {

        #region Private Variables
        private string branch;
        private string branchBonus;
        private string branchBonusEarned;
        private string branchExceededGoal;
        private string branchGoal;
        private string branchIncrement;
        private string branchIncrementBonus;
        private string branchYearToDate;
        private string companyBonus;
        private string companyBonusEarned;
        private string companyGoal;
        private string companyYearToDate;
        private string name;
        private Guid rowId;
        private string year;
        #endregion

        #region Methods

            #region Load(Row row)
            /// <summary>
            /// This method loads a BonusSettings object from a Row.
            /// </Summary>
            /// <param name="row">The row which the row.Columns[x].ColumnValue will be used to load this object.</param>
            public void Load(Row row)
            {
                // If the row exists and the row's column collection exists
                if ((NullHelper.Exists(row)) && (row.HasColumns))
                {
                    Branch = row.Columns[0].StringValue;
                    Name = row.Columns[1].StringValue;
                    Year = row.Columns[2].StringValue;
                    CompanyGoal = row.Columns[3].StringValue;
                    CompanyYearToDate = row.Columns[4].StringValue;
                    CompanyBonus = row.Columns[5].StringValue;
                    BranchGoal = row.Columns[6].StringValue;
                    BranchIncrement = row.Columns[7].StringValue;
                    BranchYearToDate = row.Columns[8].StringValue;
                    BranchBonus = row.Columns[9].StringValue;
                    BranchIncrementBonus = row.Columns[10].StringValue;
                    BranchExceededGoal = row.Columns[11].StringValue;
                    CompanyBonusEarned = row.Columns[12].StringValue;
                    BranchBonusEarned = row.Columns[13].StringValue;
                }

                // Set RowId
                RowId = row.Id;
            }
            #endregion

            #region Load(Worksheet worksheet)
            /// <summary>
            /// This method loads a list of BonusSettings objects from a Worksheet.
            /// </Summary>
            /// <param name="worksheet">The worksheet which the rows collection will be used to load a list of BonusSettings objects.</param>
            public static List<BonusSettings> Load(Worksheet worksheet)
            {
                // Initial value
                List<BonusSettings> bonusSettingsList = new List<BonusSettings>();
                
                // If the worksheet exists and the row's collection exists
                if ((NullHelper.Exists(worksheet)) && (worksheet.HasRows))
                {
                    // Iterate the worksheet.Rows collection
                    foreach (Row row in worksheet.Rows)
                    {
                        // If the row is not a HeaderRow and row's column collection exists
                        if ((!row.IsHeaderRow) && (row.HasColumns))
                        {
                            // Create a new instance of a BonusSettings object.
                            BonusSettings bonusSettings = new BonusSettings();
                            
                            // Load this object
                            bonusSettings.Load(row);
                            
                            // Add this object to the list
                            bonusSettingsList.Add(bonusSettings);
                        }
                    }
                }
                
                // return value
                return bonusSettingsList;
            }
            #endregion

            #region NewRow(Row row)
            /// <summary>
            /// This method creates the columns for the row to save a new BonusSettings object.
            /// </Summary>
            /// <param name="row">The row which the Columns will be created for.</param>
            public static Row NewRow(int rowNumber)
            {
                // initial value
                Row newRow = new Row();

                // Create Column
                Column branchColumn = new Column("Branch", rowNumber, 1, DataManager.DataTypeEnum.String);

                // Add this column
                newRow.Columns.Add(branchColumn);

                // Create Column
                Column nameColumn = new Column("Name", rowNumber, 2, DataManager.DataTypeEnum.String);

                // Add this column
                newRow.Columns.Add(nameColumn);

                // Create Column
                Column yearColumn = new Column("Year", rowNumber, 3, DataManager.DataTypeEnum.String);

                // Add this column
                newRow.Columns.Add(yearColumn);

                // Create Column
                Column companyGoalColumn = new Column("CompanyGoal", rowNumber, 4, DataManager.DataTypeEnum.String);

                // Add this column
                newRow.Columns.Add(companyGoalColumn);

                // Create Column
                Column companyYearToDateColumn = new Column("CompanyYearToDate", rowNumber, 5, DataManager.DataTypeEnum.String);

                // Add this column
                newRow.Columns.Add(companyYearToDateColumn);

                // Create Column
                Column companyBonusColumn = new Column("CompanyBonus", rowNumber, 6, DataManager.DataTypeEnum.String);

                // Add this column
                newRow.Columns.Add(companyBonusColumn);

                // Create Column
                Column branchGoalColumn = new Column("BranchGoal", rowNumber, 7, DataManager.DataTypeEnum.String);

                // Add this column
                newRow.Columns.Add(branchGoalColumn);

                // Create Column
                Column branchIncrementColumn = new Column("BranchIncrement", rowNumber, 8, DataManager.DataTypeEnum.String);

                // Add this column
                newRow.Columns.Add(branchIncrementColumn);

                // Create Column
                Column branchYearToDateColumn = new Column("BranchYearToDate", rowNumber, 9, DataManager.DataTypeEnum.String);

                // Add this column
                newRow.Columns.Add(branchYearToDateColumn);

                // Create Column
                Column branchBonusColumn = new Column("BranchBonus", rowNumber, 10, DataManager.DataTypeEnum.String);

                // Add this column
                newRow.Columns.Add(branchBonusColumn);

                // Create Column
                Column branchIncrementBonusColumn = new Column("BranchIncrementBonus", rowNumber, 11, DataManager.DataTypeEnum.String);

                // Add this column
                newRow.Columns.Add(branchIncrementBonusColumn);

                // Create Column
                Column branchExceededGoalColumn = new Column("BranchExceededGoal", rowNumber, 12, DataManager.DataTypeEnum.String);

                // Add this column
                newRow.Columns.Add(branchExceededGoalColumn);

                // Create Column
                Column companyBonusEarnedColumn = new Column("CompanyBonusEarned", rowNumber, 13, DataManager.DataTypeEnum.String);

                // Add this column
                newRow.Columns.Add(companyBonusEarnedColumn);

                // Create Column
                Column branchBonusEarnedColumn = new Column("BranchBonusEarned", rowNumber, 14, DataManager.DataTypeEnum.String);

                // Add this column
                newRow.Columns.Add(branchBonusEarnedColumn);

                // return value
                return newRow;
            }
            #endregion

            #region Save(Row row)
            /// <summary>
            /// This method saves a BonusSettings object back to a Row.
            /// </Summary>
            /// <param name="row">The row which the row.Columns[x].ColumnValue will be set to Save back to Excel.</param>
            public Row Save(Row row)
            {
                // If the row exists and the row's column collection exists
                if ((NullHelper.Exists(row)) && (row.HasColumns))
                {
                    row.Columns[0].ColumnValue = Branch;
                    row.Columns[1].ColumnValue = Name;
                    row.Columns[2].ColumnValue = Year;
                    row.Columns[3].ColumnValue = CompanyGoal;
                    row.Columns[4].ColumnValue = CompanyYearToDate;
                    row.Columns[5].ColumnValue = CompanyBonus;
                    row.Columns[6].ColumnValue = BranchGoal;
                    row.Columns[7].ColumnValue = BranchIncrement;
                    row.Columns[8].ColumnValue = BranchYearToDate;
                    row.Columns[9].ColumnValue = BranchBonus;
                    row.Columns[10].ColumnValue = BranchIncrementBonus;
                    row.Columns[11].ColumnValue = BranchExceededGoal;
                    row.Columns[12].ColumnValue = CompanyBonusEarned;
                    row.Columns[13].ColumnValue = BranchBonusEarned;
                }

                // return value
                return row;
            }
            #endregion

        #endregion

        #region Properties

            #region string Branch
            public string Branch
            {
                get
                {
                    return branch;
                }
                set
                {
                    branch = value;
                }
            }
            #endregion

            #region string BranchBonus
            public string BranchBonus
            {
                get
                {
                    return branchBonus;
                }
                set
                {
                    branchBonus = value;
                }
            }
            #endregion

            #region string BranchBonusEarned
            public string BranchBonusEarned
            {
                get
                {
                    return branchBonusEarned;
                }
                set
                {
                    branchBonusEarned = value;
                }
            }
            #endregion

            #region string BranchExceededGoal
            public string BranchExceededGoal
            {
                get
                {
                    return branchExceededGoal;
                }
                set
                {
                    branchExceededGoal = value;
                }
            }
            #endregion

            #region string BranchGoal
            public string BranchGoal
            {
                get
                {
                    return branchGoal;
                }
                set
                {
                    branchGoal = value;
                }
            }
            #endregion

            #region string BranchIncrement
            public string BranchIncrement
            {
                get
                {
                    return branchIncrement;
                }
                set
                {
                    branchIncrement = value;
                }
            }
            #endregion

            #region string BranchIncrementBonus
            public string BranchIncrementBonus
            {
                get
                {
                    return branchIncrementBonus;
                }
                set
                {
                    branchIncrementBonus = value;
                }
            }
            #endregion

            #region string BranchYearToDate
            public string BranchYearToDate
            {
                get
                {
                    return branchYearToDate;
                }
                set
                {
                    branchYearToDate = value;
                }
            }
            #endregion

            #region string CompanyBonus
            public string CompanyBonus
            {
                get
                {
                    return companyBonus;
                }
                set
                {
                    companyBonus = value;
                }
            }
            #endregion

            #region string CompanyBonusEarned
            public string CompanyBonusEarned
            {
                get
                {
                    return companyBonusEarned;
                }
                set
                {
                    companyBonusEarned = value;
                }
            }
            #endregion

            #region string CompanyGoal
            public string CompanyGoal
            {
                get
                {
                    return companyGoal;
                }
                set
                {
                    companyGoal = value;
                }
            }
            #endregion

            #region string CompanyYearToDate
            public string CompanyYearToDate
            {
                get
                {
                    return companyYearToDate;
                }
                set
                {
                    companyYearToDate = value;
                }
            }
            #endregion

            #region string Name
            public string Name
            {
                get
                {
                    return name;
                }
                set
                {
                    name = value;
                }
            }
            #endregion

            #region Guid RowId
            public Guid RowId
            {
                get
                {
                    return rowId;
                }
                set
                {
                    rowId = value;
                }
            }
            #endregion

            #region string Year
            public string Year
            {
                get
                {
                    return year;
                }
                set
                {
                    year = value;
                }
            }
            #endregion

        #endregion

    }
    #endregion

}